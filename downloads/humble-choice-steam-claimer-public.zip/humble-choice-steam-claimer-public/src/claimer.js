import { chromium } from 'playwright';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

const rl = readline.createInterface({ input, output });
const startUrl = process.env.HUMBLE_CHOICE_URL || 'https://www.humblebundle.com/membership/home';

async function pause(message) {
  await rl.question(`${message}\nPress Enter to continue, or Ctrl+C to stop. `);
}

const browser = await chromium.launch({ headless: false, slowMo: 150 });
const context = await browser.newContext();
const page = await context.newPage();

try {
  console.log('Opening Humble Choice in a visible browser window.');
  await page.goto(startUrl, { waitUntil: 'domcontentloaded' });

  await pause('Sign in to Humble manually, complete any prompts, and navigate to the Choice redemption page.');

  console.log('Looking for Steam-related buttons or links on the current page.');
  const candidates = page.getByRole('link', { name: /steam|redeem|claim|get key/i });
  const count = await candidates.count();
  console.log(`Found ${count} possible redemption links/buttons. Review the page before continuing.`);

  await pause('If the page is ready and you want to continue supervised navigation, press Enter.');

  for (let index = 0; index < count; index += 1) {
    const item = candidates.nth(index);
    if (!(await item.isVisible().catch(() => false))) continue;

    console.log(`Opening candidate ${index + 1} of ${count}.`);
    await item.click();
    await page.waitForLoadState('domcontentloaded').catch(() => {});
    await pause('Review the browser. Complete Steam login, Steam Guard, captcha, ownership confirmation, or redemption manually if shown.');
  }

  await pause('Review final results in Humble and Steam.');
} finally {
  await browser.close();
  rl.close();
}
