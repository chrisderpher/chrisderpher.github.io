# Humble Choice Steam Claimer Public

A supervised Playwright helper for users redeeming Steam keys they already own from their own Humble Choice account.

## Boundaries

- Use only with your own Humble and Steam accounts.
- This does not bypass payment, logins, Steam Guard, captchas, ownership checks, regional limits, rate limits, or account restrictions.
- Keep the browser visible and supervise the run.
- Complete all authentication, Steam Guard, captcha, and confirmation prompts yourself.
- Stop immediately if Humble or Steam shows an unexpected warning.

## Setup

```bash
npm install
npx playwright install
```

## Run

```bash
npm start
```

Optionally provide a specific starting URL:

```bash
HUMBLE_CHOICE_URL="https://www.humblebundle.com/membership/home" npm start
```

The script opens a visible Chromium window and pauses at key checkpoints so you can handle account-sensitive actions manually.
