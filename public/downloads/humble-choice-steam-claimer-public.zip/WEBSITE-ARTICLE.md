# Automating Humble Choice Steam Redemptions With Playwright

Every month I would open my Humble Choice page, click a game, click **Get game on Steam**, click **Redeem**, land on Steam, check the subscriber agreement box, activate the key, close the tab, go back to Humble, and do it all again for the next game.

It is not hard work. It is just perfectly shaped to be annoying.

So I made a small supervised Playwright script that does the repetitive clicking for me while I watch. It does not bypass payment, ownership, Steam Guard, logins, captchas, or anything like that. It just automates the browser steps for games already available in your own Humble account.

## What Playwright Is

[Playwright](https://playwright.dev/) is a browser automation framework. In plain English: it lets a script open a real browser, navigate to web pages, click buttons, read visible page content, wait for page changes, and handle tabs/popups.

The official Playwright docs describe it as an end-to-end testing framework for modern web apps, and the Playwright GitHub README also calls out browser automation scripts as a supported use case. It can drive Chromium, Firefox, and WebKit with one API.

If you remember older Selenium automation, this is the same general idea: a program controls a browser. The difference is that Playwright feels much better suited to modern JavaScript-heavy websites. It has good waiting behavior, clean element locators, easy tab handling, and a simple way to launch a visible browser profile.

For this project, that matters because Humble and Steam are not static old-school pages. Buttons appear after state changes, redemptions open new pages/tabs, and the Humble game list is a modal carousel. Playwright gives the script enough browser awareness to handle that without resorting to blind screen-coordinate clicking.

## What This Script Does

The script opens a visible browser and waits for you to confirm that the Humble Choice game grid is on screen. Then it:

1. Detects the games on the Humble Choice page.
2. Opens the first game.
3. Clicks **Get game on Steam**.
4. Waits for the key area to appear.
5. Clicks **Redeem**.
6. Switches to the Steam activation page.
7. Checks the Steam subscriber agreement box.
8. Clicks the activation button.
9. Closes the Steam tab.
10. Returns to Humble and advances to the next game with the right chevron.

The browser is visible the whole time, and `Ctrl+C` stops the script from PowerShell.

## Before You Use It

Use this only on your own accounts and your own bundle games. You are responsible for respecting Humble's and Steam's terms, account security requirements, region restrictions, and activation limits.

This script intentionally does not try to bypass Steam Guard, captchas, login checks, payment, ownership checks, or errors. If a page asks for something sensitive, do it yourself in the visible browser.

Websites change. If Humble or Steam changes their HTML, the script may need an update. Start with a dry run each month.

## Requirements

- Windows 10/11
- Node.js 20 or newer from <https://nodejs.org/>
- A Humble Choice month URL, like `https://www.humblebundle.com/membership/july-2026`

## Download

Download the script folder:

`humble-choice-steam-claimer-public`

The folder includes:

- `humble-choice-steam-claimer.mjs`: the Playwright automation script
- `run-humble-claimer.ps1`: a PowerShell launcher
- `package.json`: the Node/Playwright dependency file
- `README.md`: quick usage instructions

## First Run

Open PowerShell in the extracted folder and run:

```powershell
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -DryRun
```

Example:

```powershell
.\run-humble-claimer.ps1 -Url "https://www.humblebundle.com/membership/july-2026" -DryRun
```

The first run installs Playwright locally and installs Playwright's Chromium browser as a fallback. It also creates a `browser-profile` folder, which stores the browser login session for the automation browser. You may need to sign into Humble and Steam once in that browser.

If PowerShell blocks the script, use:

```powershell
powershell -ExecutionPolicy Bypass -File .\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -DryRun
```

## Running It

After the dry run detects the right games, run:

```powershell
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL"
```

That mode pauses before each game and before each Steam activation page.

Once you trust the flow and are still watching the browser, run:

```powershell
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -Continuous
```

## Useful Options

```powershell
# Revisit cards already marked CLAIMED.
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -IncludeClaimed

# Use a specific order instead of automatic detection.
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -Games "Game One; Game Two; Game Three"

# Leave Steam activation tabs open after each attempt.
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -KeepSteamOpen

# Reopen each game from the grid instead of using the Humble modal's right chevron.
.\run-humble-claimer.ps1 -Url "HUMBLE_MONTH_URL" -GridNavigation
```

## Why This Exists

I wanted this for years. Back when I first played with browser automation, Selenium was the tool I reached for, and getting small personal automations stable could be fiddly. Playwright makes this kind of practical browser scripting feel much more approachable.

This is the sweet spot for automation: not replacing judgment, not bypassing rules, just removing repetitive clicking from something you are already allowed to do.

## Sources

- Playwright documentation: <https://playwright.dev/docs/intro>
- Playwright GitHub README: <https://github.com/microsoft/playwright>
